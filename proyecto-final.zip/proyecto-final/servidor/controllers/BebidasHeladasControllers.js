const Bebidas  = require('../models/Bebidas_heladas');

//CRUD
//tomar 


exports.lista = async(req, res) => {
    try{
        const tomar = await Bebidas.find();
        res.json(tomar);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const tomar = await Bebidas.findById(id);
        if(!tomar){
            res.status(404).json({
                mensaje: 'La bebida no existe'
            })
        }
        res.json(tomar);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const tomar = new Bebidas(req.body);
    try {
        await tomar.save();
        res.json({
            mensaje: 'Se creo una bebida'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const tomar = await Bebidas.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo la bebida'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const tomar = await Bebidas.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino la bebida ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}