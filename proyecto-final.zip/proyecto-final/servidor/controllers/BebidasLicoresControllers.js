const Bebidas  = require('../models/Bebidas_licores');

//CRUD
//licor 


exports.lista = async(req, res) => {
    try{
        const licor = await Bebidas.find();
        res.json(licor);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const licor = await Bebidas.findById(id);
        if(!licor){
            res.status(404).json({
                mensaje: 'La bebida no existe'
            })
        }
        res.json(licor);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const licor = new Bebidas(req.body);
    try {
        await licor.save();
        res.json({
            mensaje: 'Se creo una bebida'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const licor = await Bebidas.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo la bebida'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const licor = await Bebidas.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino la bebida ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}