const Cajas  = require('../models/Cajas');

//CRUD
//Caja 


exports.lista = async(req, res) => {
    try{
        const Caja = await Cajas.find();
        res.json(Caja);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const Caja = await Cajas.findById(id);
        if(!Caja){
            res.status(404).json({
                mensaje: 'La caja no existe'
            })
        }
        res.json(Caja);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const Caja = new Cajas(req.body);
    try {
        await Caja.save();
        res.json({
            mensaje: 'Se creo una caja'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const Caja = await Cajas.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo la caja'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const Caja = await Cajas.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino la caja ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}