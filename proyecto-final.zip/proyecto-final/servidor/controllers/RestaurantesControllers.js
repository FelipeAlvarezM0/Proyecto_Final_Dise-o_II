const Restaurantes  = require('../models/Restaurante');

//CRUD

exports.lista = async(req, res) => {
    try{
        const Restaurante = await Restaurantes.find();
        res.json(Restaurante);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const Restaurante = await Restaurantes.findById(id);
        if(!Restaurante){
            res.status(404).json({
                mensaje: 'El restaurante no existe'
            })
        }
        res.json(Restaurante);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const Restaurante = new Restaurantes(req.body);
    try {
        await Restaurante.save();
        res.json({
            mensaje: 'Se creo un restaurante'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const Restaurante = await Restaurantes.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo el restaurante'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const Restaurante = await Restaurantes.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino el restaurante ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}