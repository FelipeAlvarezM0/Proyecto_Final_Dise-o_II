const Marcas  = require('../models/Marcas');

//CRUD

exports.lista = async(req, res) => {
    try{
        const marca = await Marcas.find();
        res.json(marca);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const marca = await Marcas.findById(id);
        if(!marca){
            res.status(404).json({
                mensaje: 'La marca no existe'
            })
        }
        res.json(marca);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const marca = new Marcas(req.body);
    try {
        await marca.save();
        res.json({
            mensaje: 'Se creo un marca'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const marca = await Marcas.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo la marca'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const marca = await Marcas.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino el marca ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}