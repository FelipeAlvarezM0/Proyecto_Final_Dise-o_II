const Puestos  = require('../models/Puesto');

//CRUD

exports.lista = async(req, res) => {
    try{
        const Puesto = await Puestos.find();
        res.json(Puesto);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const Puesto = await Puestos.findById(id);
        if(!Puesto){
            res.status(404).json({
                mensaje: 'El puesto no existe'
            })
        }
        res.json(Puesto);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const Puesto = new Puestos(req.body);
    try {
        await Puesto.save();
        res.json({
            mensaje: 'Se creo un puesto'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const Puesto = await Puestos.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo el puesto'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const Puesto = await Puestos.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino el puesto ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}