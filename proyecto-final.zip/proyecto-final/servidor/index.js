const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');

const routes = require('./routes');

const app = express();
const hostname = '127.0.0.1';
const port = '5000';

mongoose.Promise = global.Promise;
mongoose.connect(`mongodb://localhost:27017/restaurante`,{
    useNewUrlParser: true,
    useUnifiedTopology: true
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

app.use(cors());

app.listen(port,hostname,()=>{
    console.log(`Server running at http://${hostname}:${port}/`);
});


app.use('/',routes());