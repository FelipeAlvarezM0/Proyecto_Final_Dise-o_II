const mongoose = require('mongoose');

const Schema  = mongoose.Schema;

const marcaSchema = new Schema({
    "codigo":{
        type: String,
    },
    "nombre":{
        type: String,
        trim: true
    },
    "descripcion":{
        type: String
    },
    "nacionalidad":{
        type: String
    },
    "nombreEmpresa": {
        type: String
    },
    "telefono": {
        type: Number
    },
    "detalle": {
        type: String
    },
    "cedulaJuridica": {
        type: String
    },
    "estado":{
        type: Boolean
    }
});

const marca = mongoose.model('marca', marcaSchema);

module.exports = marca;