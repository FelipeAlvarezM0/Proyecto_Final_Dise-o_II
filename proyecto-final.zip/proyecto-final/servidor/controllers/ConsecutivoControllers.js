const Consecutivo  = require('../models/Consecutivo');

//CRUD
//consecutivo 
//Consecutivo

exports.lista = async(req, res) => {
    try{
        const consecutivo = await Consecutivo.find();
        res.json(consecutivo);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const consecutivo = await Consecutivo.findById(id);
        if(!consecutivo){
            res.status(404).json({
                mensaje: 'El consecutivo no existe'
            })
        }
        res.json(consecutivo);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const consecutivo = new Consecutivo(req.body);
    try {
        await consecutivo.save();
        res.json({
            mensaje: 'Se creo un consecutivo'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const consecutivo = await Consecutivo.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo el consecutivo'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const consecutivo = await Consecutivo.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino el consecutivo ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}