const Equipos  = require('../models/Equipo');

//CRUD
//Equipo 


exports.lista = async(req, res) => {
    try{
        const Equipo = await Equipos.find();
        res.json(Equipo);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const Equipo = await Equipos.findById(id);
        if(!Equipo){
            res.status(404).json({
                mensaje: 'El equipo no existe'
            })
        }
        res.json(Equipo);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const Equipo = new Equipos(req.body);
    try {
        await Equipo.save();
        res.json({
            mensaje: 'Se creo un equipo'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const Equipo = await Equipos.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo el equipo'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const Equipo = await Equipos.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino el equipo ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}