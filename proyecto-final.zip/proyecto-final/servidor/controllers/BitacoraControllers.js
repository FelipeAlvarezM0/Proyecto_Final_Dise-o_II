const Bitacoras  = require('../models/Bitacora');

//CRUD
//Bitacora 


exports.lista = async(req, res) => {
    try{
        const Bitacora = await Bitacoras.find();
        res.json(Bitacora);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const Bitacora = await Bitacoras.findById(id);
        if(!Bitacora){
            res.status(404).json({
                mensaje: 'La bitacora no existe'
            })
        }
        res.json(Bitacora);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const Bitacora = new Bitacoras(req.body);
    try {
        await Bitacora.save();
        res.json({
            mensaje: 'Se creo una bitacora'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const Bitacora = await Bitacoras.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo la bitacora'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const Bitacora = await Bitacoras.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino la bitacora ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}