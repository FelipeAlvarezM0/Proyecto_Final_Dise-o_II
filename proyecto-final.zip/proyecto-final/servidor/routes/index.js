const express = require('express');
const router  = express.Router(); 

const EmpleadosControllers = require('../controllers/EmpleadosControllers');
const MarcasControllers = require('../controllers/MarcasControllers');
const ComestiblesControllers = require('../controllers/ComestiblesControllers');
const ConsecutivoControllers = require('../controllers/ConsecutivoControllers');
const UsuariosControllers = require('../controllers/UsuariosControllers');
const BebidasCalientesControllers = require('../controllers/BebidasCalientesControllers');
const BebidasGaseosasControllers = require('../controllers/BebidasGaseosasControllers');
const BebidasHeladasControlers = require('../controllers/BebidasHeladasControllers');
const BebidasLicoresControllers = require('../controllers/BebidasLicoresControllers');
const BebidasVinosControllers = require('../controllers/BebidasVinosControllers');
const BitacoraControllers = require('../controllers/BitacoraControllers');
const CajasControllers = require('../controllers/CajasControllers');
const ClientesControllers = require('../controllers/ClientesControllers');
const EmpaquesControllers = require('../controllers/EmpaquesControllers');
const EquipoControllers = require('../controllers/EquipoControllers');
const EspecialidadesControllers = require('../controllers/EspecialidadesControllers');
const LimpiezaControllers = require('../controllers/LimpiezaControllers');
const MesaControllers = require('../controllers/MesaControllers');
const PaisControllers = require('../controllers/PaisControllers');
const ProductoLimpiezaControllers = require('../controllers/ProductosLimpiezaControllers');
const ProvedorControllers = require('../controllers/ProvedoresControllers');
const PuestoControllers = require('../controllers/PuestosControllers');
const RestauranteActividadControllers = require('../controllers/RestauranteAControllers');
const RestaurantesControllers = require('../controllers/RestaurantesControllers');
const RolesControllers = require('../controllers/RolesControllers');
const TecnologiaControllers = require('../controllers/TecnologiaControllers');
const UnidadMedidaControllers = require('../controllers/UnidadMedidaControllers');
const UsuarioActividadControllers = require('../controllers/ActividadesControllers');



module.exports = function(){
    //Empleado
    router.get('/empleado', EmpleadosControllers.lista);
    router.get('/empleado/:id', EmpleadosControllers.seleccionado);
    router.post('/empleado', EmpleadosControllers.agregar);
    router.put('/empleado/:id', EmpleadosControllers.actualizar);
    router.delete('/empleado/:id', EmpleadosControllers.eliminar);

    //Marcas
    router.get('/marca', MarcasControllers.lista);
    router.get('/marca/:id', MarcasControllers.seleccionado);
    router.post('/marca', MarcasControllers.agregar);
    router.put('/marca/:id', MarcasControllers.actualizar);
    router.delete('/marca/:id', MarcasControllers.eliminar);

    //Comestibles
    router.get('/comestible', ComestiblesControllers.lista)
    router.get('/comestible/:id', ComestiblesControllers.seleccionado);
    router.post('/comestible', ComestiblesControllers.agregar);
    router.put('/comestible/:id', ComestiblesControllers.actualizar);
    router.delete('/comestible/:id', ComestiblesControllers.eliminar);

    //Consecutivo
    router.get('/consecutivo', ConsecutivoControllers.lista);
    router.get('/consecutivo/:id', ConsecutivoControllers.seleccionado);
    router.post('/consecutivo', ConsecutivoControllers.agregar);
    router.put('/consecutivo/:id', ConsecutivoControllers.actualizar);
    router.delete('/consecutivo/:id', ConsecutivoControllers.eliminar);

    //Usuarios
    router.get('/usuario', UsuariosControllers.lista);
    router.get('/usuario/:id', UsuariosControllers.seleccionado);
    router.post('/usuario', UsuariosControllers.agregar);
    router.put('/usuario/:id', UsuariosControllers.actualizar);
    router.delete('/usuario/:id', UsuariosControllers.eliminar);

    //Bebidas calientes
    router.get('/bebida', BebidasCalientesControllers.lista);
    router.get('/bebida/:id', BebidasCalientesControllers.seleccionado);
    router.post('/bebida', BebidasCalientesControllers.agregar);
    router.put('/bebida/:id', BebidasCalientesControllers.actualizar);
    router.delete('/bebida/:id', BebidasCalientesControllers.eliminar);

    //Bebidas gaseosas
    router.get('/fresco', BebidasGaseosasControllers.lista);
    router.get('/fresco/:id', BebidasGaseosasControllers.seleccionado);
    router.post('/fresco', BebidasGaseosasControllers.agregar);
    router.put('/fresco/:id', BebidasGaseosasControllers.actualizar);
    router.delete('/fresco/:id', BebidasGaseosasControllers.eliminar);

    //Bebidas heladas
    router.get('/tomar', BebidasHeladasControlers.lista);
    router.get('/tomar/:id', BebidasHeladasControlers.seleccionado);
    router.post('/tomar', BebidasHeladasControlers.agregar);
    router.put('/tomar/:id', BebidasHeladasControlers.actualizar);
    router.delete('/tomar/:id', BebidasHeladasControlers.eliminar);

    //Bebidas con licor
    router.get('/licor', BebidasLicoresControllers.lista);
    router.get('/licor/:id', BebidasLicoresControllers.seleccionado);
    router.post('/licor', BebidasLicoresControllers.agregar);
    router.put('/licor/:id', BebidasLicoresControllers.actualizar);
    router.delete('/licor/:id', BebidasLicoresControllers.eliminar);

    //Bebidas con vino
    router.get('/vino', BebidasVinosControllers.lista);
    router.get('/vino/:id', BebidasVinosControllers.seleccionado);
    router.post('/vino', BebidasVinosControllers.agregar);
    router.put('/vino/:id', BebidasVinosControllers.actualizar);
    router.delete('/vino/:id', BebidasVinosControllers.eliminar);

    //Bitacora
    router.get('/Bitacora', BitacoraControllers.lista);
    router.get('/Bitacora/:id', BitacoraControllers.seleccionado);
    router.post('/Bitacora', BitacoraControllers.agregar);
    router.put('/Bitacora/:id', BitacoraControllers.actualizar);
    router.delete('/Bitacora/:id', BitacoraControllers.eliminar);

    //Cajas
    router.get('/Caja', CajasControllers.lista);
    router.get('/Caja/:id', CajasControllers.seleccionado);
    router.post('/Caja', CajasControllers.agregar);
    router.put('/Caja/:id', CajasControllers.actualizar);
    router.delete('/Caja/:id', CajasControllers.eliminar);

    //Clientes
    router.get('/Cliente', ClientesControllers.lista);
    router.get('/Cliente/:id', ClientesControllers.seleccionado);
    router.post('/Cliente', ClientesControllers.agregar);
    router.put('/Cliente/:id', ClientesControllers.actualizar);
    router.delete('/Cliente/:id', ClientesControllers.eliminar);

    //Empaques
    router.get('/Empaque', EmpaquesControllers.lista);
    router.get('/Empaque/:id', EmpaquesControllers.seleccionado);
    router.post('/Empaque', EmpaquesControllers.agregar);
    router.put('/Empaque/:id', EmpaquesControllers.actualizar);
    router.delete('/Empaque/:id', EmpaquesControllers.eliminar);

    //Equipo
    router.get('/Equipo', EquipoControllers.lista);
    router.get('/Equipo/:id', EquipoControllers.seleccionado);
    router.post('/Equipo', EquipoControllers.agregar);
    router.put('/Equipo/:id', EquipoControllers.actualizar);
    router.delete('/Equipo/:id', EquipoControllers.eliminar);

    //Especialidades
    router.get('/especialidad', EspecialidadesControllers.lista);
    router.get('/especialidad/:id', EspecialidadesControllers.seleccionado);
    router.post('/especialidad', EspecialidadesControllers.agregar);
    router.put('/especialidad/:id', EspecialidadesControllers.actualizar);
    router.delete('/especialidad/:id', EspecialidadesControllers.eliminar);

    //Limpieza
    router.get('/Limpieza', LimpiezaControllers.lista);
    router.get('/Limpieza/:id', LimpiezaControllers.seleccionado);
    router.post('/Limpieza', LimpiezaControllers.agregar);
    router.put('/Limpieza/:id', LimpiezaControllers.actualizar);
    router.delete('/Limpieza/:id', LimpiezaControllers.eliminar);

    //Mesas
    router.get('/Meza', MesaControllers.lista);
    router.get('/Meza/:id', MesaControllers.seleccionado);
    router.post('/Meza', MesaControllers.agregar);
    router.put('/Meza/:id', MesaControllers.actualizar);
    router.delete('/Meza/:id', MesaControllers.eliminar);

    //Pais
    router.get('/Pai', PaisControllers.lista);
    router.get('/Pai/:id', PaisControllers.seleccionado);
    router.post('/Pai', PaisControllers.agregar);
    router.put('/Pai/:id', PaisControllers.actualizar);
    router.delete('/Pai/:id', PaisControllers.eliminar);

    //ProductoLimpieza
    router.get('/Producto', ProductoLimpiezaControllers.lista);
    router.get('/Producto/:id', ProductoLimpiezaControllers.seleccionado);
    router.post('/Producto', ProductoLimpiezaControllers.agregar);
    router.put('/Producto/:id', ProductoLimpiezaControllers.actualizar);
    router.delete('/Producto/:id', ProductoLimpiezaControllers.eliminar);

    //Provedor
    router.get('/Provedore', ProvedorControllers.lista);
    router.get('/Provedore/:id', ProvedorControllers.seleccionado);
    router.post('/Provedore', ProvedorControllers.agregar);
    router.put('/Provedore/:id', ProvedorControllers.actualizar);
    router.delete('/Provedore/:id', ProvedorControllers.eliminar);
    
    //Puesto
    router.get('/Puesto', PuestoControllers.lista);
    router.get('/Puesto/:id', PuestoControllers.seleccionado);
    router.post('/Puesto', PuestoControllers.agregar);
    router.put('/Puesto/:id', PuestoControllers.actualizar);
    router.delete('/Puesto/:id', PuestoControllers.eliminar);

    //RestauranteActividad
    router.get('/Actividad', RestauranteActividadControllers.lista);
    router.get('/Actividad/:id', RestauranteActividadControllers.seleccionado);
    router.post('/Actividad', RestauranteActividadControllers.agregar);
    router.put('/Actividad/:id', RestauranteActividadControllers.actualizar);
    router.delete('/Actividad/:id', RestauranteActividadControllers.eliminar);

    //Restaurantes
    router.get('/Restaurante', RestaurantesControllers.lista);
    router.get('/Restaurante/:id', RestaurantesControllers.seleccionado);
    router.post('/Restaurante', RestaurantesControllers.agregar);
    router.put('/Restaurante/:id', RestaurantesControllers.actualizar);
    router.delete('/Restaurante/:id', RestaurantesControllers.eliminar);

    //Roles RolesControllers
    router.get('/Role', RolesControllers.lista);
    router.get('/Role/:id', RolesControllers.seleccionado);
    router.post('/Role', RolesControllers.agregar);
    router.put('/Role/:id', RolesControllers.actualizar);
    router.delete('/Role/:id', RolesControllers.eliminar);
    
    //Tecnologia
    router.get('/Tecnologia', TecnologiaControllers.lista);
    router.get('/Tecnologia/:id', TecnologiaControllers.seleccionado);
    router.post('/Tecnologia', TecnologiaControllers.agregar);
    router.put('/Tecnologia/:id', TecnologiaControllers.actualizar);
    router.delete('/Tecnologia/:id', TecnologiaControllers.eliminar);

    //UnidadMedida
    router.get('/Unidade', UnidadMedidaControllers.lista);
    router.get('/Unidade/:id', UnidadMedidaControllers.seleccionado);
    router.post('/Unidade', UnidadMedidaControllers.agregar);
    router.put('/Unidade/:id', UnidadMedidaControllers.actualizar);
    router.delete('/Unidade/:id', UnidadMedidaControllers.eliminar);

    //UsuarioActividad
    router.get('/Actividade', UsuarioActividadControllers.lista);
    router.get('/Actividade/:id', UsuarioActividadControllers.seleccionado);
    router.post('/Actividade', UsuarioActividadControllers.agregar);
    router.put('/Actividade/:id', UsuarioActividadControllers.actualizar);
    router.delete('/Actividade/:id', UsuarioActividadControllers.eliminar);

    return router;
}