const Mezas  = require('../models/Mesa');

//CRUD

exports.lista = async(req, res) => {
    try{
        const Meza = await Mezas.find();
        res.json(Meza);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const Meza = await Mezas.findById(id);
        if(!Meza){
            res.status(404).json({
                mensaje: 'La meza no existe'
            })
        }
        res.json(Meza);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const Meza = new Mezas(req.body);
    try {
        await Meza.save();
        res.json({
            mensaje: 'Se creo un meza'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const Meza = await Mezas.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo la meza'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const Meza = await Mezas.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino el meza ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}