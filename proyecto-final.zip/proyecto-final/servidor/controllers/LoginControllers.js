const router = require("express").Router();
let Usuario = require("../models/Usuario");
const express = require("express");
var bcrypt = require('bcryptjs');
const app = express();



exports.Iniciar = async(req, res) => {
    try{
        const usuarioBusca = req.body.usuarioBusca;
        const passBusca = req.body.passBusca;

        const usuario  = await Usuario.findOne({ usuario : usuarioBusca });

        if(!usuario){
            return res.send(false);
        } else if(usuario){
            return res.json(await bcrypt.compare(passBusca, usuario.password))
        }
    } catch (error){
        res.status(400).send(error);
    }
}
