const Usuarios  = require('../models/Usuario');

//CRUD
//usuario
exports.lista = async(req, res) => {
    try{
        const usuario = await Usuarios.find();
        res.json(usuario);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const usuario = await Usuarios.findById(id);
        if(!usuario){
            res.status(404).json({
                mensaje: 'El usuario no existe'
            })
        }
        res.json(usuario);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const usuario = new Usuarios(req.body);
    try {
        await usuario.save();
        res.json({
            mensaje: 'Se creo un usuario'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const usuario = await Usuarios.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo la usuario'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const usuario = await Usuarios.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino el usuario ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}