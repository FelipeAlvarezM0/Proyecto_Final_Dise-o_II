const Bebidas  = require('../models/Bebidas_gaseosas');

//CRUD
//fresco 


exports.lista = async(req, res) => {
    try{
        const fresco = await Bebidas.find();
        res.json(fresco);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const fresco = await Bebidas.findById(id);
        if(!fresco){
            res.status(404).json({
                mensaje: 'La bebida no existe'
            })
        }
        res.json(fresco);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const fresco = new Bebidas(req.body);
    try {
        await fresco.save();
        res.json({
            mensaje: 'Se creo una bebida'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const fresco = await Bebidas.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo la bebida'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const fresco = await Bebidas.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino la bebida ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}