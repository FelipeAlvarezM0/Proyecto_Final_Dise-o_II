const Roles  = require('../models/Roles');

//CRUD

exports.lista = async(req, res) => {
    try{
        const Role = await Roles.find();
        res.json(Role);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const Role = await Roles.findById(id);
        if(!Role){
            res.status(404).json({
                mensaje: 'El rol no existe'
            })
        }
        res.json(Role);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const Role = new Roles(req.body);
    try {
        await Role.save();
        res.json({
            mensaje: 'Se creo un rol'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const Role = await Roles.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo el rol'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const Role = await Roles.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino el role ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}