const Provedores  = require('../models/Proveedor');

//CRUD

exports.lista = async(req, res) => {
    try{
        const Provedore = await Provedores.find();
        res.json(Provedore);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const Provedore = await Provedores.findById(id);
        if(!Provedore){
            res.status(404).json({
                mensaje: 'El proveedor no existe'
            })
        }
        res.json(Provedore);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const Provedore = new Provedores(req.body);
    try {
        await Provedore.save();
        res.json({
            mensaje: 'Se creo un proveedor'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const Provedore = await Provedores.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo el proveedor'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const Provedore = await Provedores.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino el proveedor ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}