const Bebidas  = require('../models/Bebidas_vinos');

//CRUD
//vino 


exports.lista = async(req, res) => {
    try{
        const vino = await Bebidas.find();
        res.json(vino);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const vino = await Bebidas.findById(id);
        if(!vino){
            res.status(404).json({
                mensaje: 'El vino no existe'
            })
        }
        res.json(vino);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const vino = new Bebidas(req.body);
    try {
        await vino.save();
        res.json({
            mensaje: 'Se creo un vino'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const vino = await Bebidas.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo el vino'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const vino = await Bebidas.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino el vino ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}