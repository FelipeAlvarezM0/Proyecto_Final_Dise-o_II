const Empleados  = require('../models/Empleados');

//CRUD

exports.lista = async(req, res) => {
    try{
        const empleado = await Empleados.find();
        res.json(empleado);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const empleado = await Empleados.findById(id);
        if(!empleado){
            res.status(404).json({
                mensaje: 'La persona no existe'
            })
        }
        res.json(empleado);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const empleado = new Empleados(req.body);
    try {
        await empleado.save();
        res.json({
            mensaje: 'Se creo un empleado'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const empledo = await Empleados.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo el empleado'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const empleado = await Empleados.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino el empleado ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

