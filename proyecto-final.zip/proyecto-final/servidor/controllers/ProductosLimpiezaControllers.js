const Productos  = require('../models/ProductosLimpieza');

//CRUD

exports.lista = async(req, res) => {
    try{
        const Producto = await Productos.find();
        res.json(Producto);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const Producto = await Productos.findById(id);
        if(!Producto){
            res.status(404).json({
                mensaje: 'El producto no existe'
            })
        }
        res.json(Producto);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const Producto = new Productos(req.body);
    try {
        await Producto.save();
        res.json({
            mensaje: 'Se creo un producto'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const Producto = await Productos.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo el producto'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const Producto = await Productos.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino el producto ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}