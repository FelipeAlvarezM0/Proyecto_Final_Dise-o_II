const Comestibles  = require('../models/Comestibles');

//CRUD
//comestible 
//Comestibles

exports.lista = async(req, res) => {
    try{
        const comestible = await Comestibles.find();
        res.json(comestible);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const comestible = await Comestibles.findById(id);
        if(!comestible){
            res.status(404).json({
                mensaje: 'El comestible no existe'
            })
        }
        res.json(comestible);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const comestible = new Comestibles(req.body);
    try {
        await comestible.save();
        res.json({
            mensaje: 'Se creo un comestible'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const comestible = await Comestibles.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo el comestible'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const comestible = await Comestibles.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino el comestible ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}