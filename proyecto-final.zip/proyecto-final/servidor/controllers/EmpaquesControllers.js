const Empaques  = require('../models/Empaques');

//CRUD
//Empaque 


exports.lista = async(req, res) => {
    try{
        const Empaque = await Empaques.find();
        res.json(Empaque);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const Empaque = await Empaques.findById(id);
        if(!Empaque){
            res.status(404).json({
                mensaje: 'El empaque no existe'
            })
        }
        res.json(Empaque);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const Empaque = new Empaques(req.body);
    try {
        await Empaque.save();
        res.json({
            mensaje: 'Se creo un empaque'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const Empaque = await Empaques.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo el empaque'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const Empaque = await Empaques.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino el empaque ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}