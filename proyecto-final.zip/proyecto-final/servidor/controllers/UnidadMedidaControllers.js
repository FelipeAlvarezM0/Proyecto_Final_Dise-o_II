const Unidades  = require('../models/Unidad_medida');

//CRUD
//Unidade 


exports.lista = async(req, res) => {
    try{
        const Unidade = await Unidades.find();
        res.json(Unidade);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const Unidade = await Unidades.findById(id);
        if(!Unidade){
            res.status(404).json({
                mensaje: 'La unidad de medida no existe'
            })
        }
        res.json(Unidade);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const Unidade = new Unidades(req.body);
    try {
        await Unidade.save();
        res.json({
            mensaje: 'Se creo una unidad de medida'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const Unidade = await Unidades.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo la unidad de medida'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const Unidade = await Unidades.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino la unidad de medida ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}