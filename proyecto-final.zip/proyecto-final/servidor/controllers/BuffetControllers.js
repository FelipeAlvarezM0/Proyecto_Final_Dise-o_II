const Buffets  = require('../models/Buffet');

//CRUD
//Buffet 


exports.lista = async(req, res) => {
    try{
        const Buffet = await Buffets.find();
        res.json(Buffet);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const Buffet = await Buffets.findById(id);
        if(!Buffet){
            res.status(404).json({
                mensaje: 'El buffet no existe'
            })
        }
        res.json(Buffet);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const Buffet = new Buffets(req.body);
    try {
        await Buffet.save();
        res.json({
            mensaje: 'Se creo un buffet'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const Buffet = await Buffets.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo el buffet'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const Buffet = await Buffets.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino el buffet ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}