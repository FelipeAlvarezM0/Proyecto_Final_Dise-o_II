const Actividads  = require('../models/Restaurante_actividad');

//CRUD

exports.lista = async(req, res) => {
    try{
        const Actividad = await Actividads.find();
        res.json(Actividad);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const Actividad = await Actividads.findById(id);
        if(!Actividad){
            res.status(404).json({
                mensaje: 'La actividad no existe'
            })
        }
        res.json(Actividad);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const Actividad = new Actividads(req.body);
    try {
        await Actividad.save();
        res.json({
            mensaje: 'Se creo una actividad'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const Actividad = await Actividads.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo la actividad'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const Actividad = await Actividads.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino la actividad ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}