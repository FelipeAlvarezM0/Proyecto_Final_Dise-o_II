const Limpiezas  = require('../models/Limpieza');

//CRUD

exports.lista = async(req, res) => {
    try{
        const Limpieza = await Limpiezas.find();
        res.json(Limpieza);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const Limpieza = await Limpiezas.findById(id);
        if(!Limpieza){
            res.status(404).json({
                mensaje: 'La limpieza no existe'
            })
        }
        res.json(Limpieza);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const Limpieza = new Limpiezas(req.body);
    try {
        await Limpieza.save();
        res.json({
            mensaje: 'Se creo un limpieza'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const Limpieza = await Limpiezas.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo la limpieza'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const Limpieza = await Limpiezas.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino la limpieza ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}