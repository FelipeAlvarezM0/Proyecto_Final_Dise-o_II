const Clientes  = require('../models/Clientes');

//CRUD
//Cliente 


exports.lista = async(req, res) => {
    try{
        const Cliente = await Clientes.find();
        res.json(Cliente);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const Cliente = await Clientes.findById(id);
        if(!Cliente){
            res.status(404).json({
                mensaje: 'El cliente no existe'
            })
        }
        res.json(Cliente);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const Cliente = new Clientes(req.body);
    try {
        await Cliente.save();
        res.json({
            mensaje: 'Se creo un cliente'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const Cliente = await Clientes.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo el cliente'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const Cliente = await Clientes.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino el cliente ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}