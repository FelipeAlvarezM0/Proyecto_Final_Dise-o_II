const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let bitacoraSchema = new Schema({
    codigo: {
        type: String
    },
    usuario: { 
        type: String
    },
    rol_usuario: {
        type: String
    },
    fecha: {
        type: String
    },
    descripcion: {
        type: String
    }
})

const Bitacora = mongoose.model('bitacora', bitacoraSchema);

module.exports = Bitacora;