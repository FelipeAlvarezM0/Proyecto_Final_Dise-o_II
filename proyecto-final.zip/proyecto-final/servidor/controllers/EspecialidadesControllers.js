const Especialidades  = require('../models/Especialidades');

//CRUD
//especialidad 


exports.lista = async(req, res) => {
    try{
        const especialidad = await Especialidades.find();
        res.json(especialidad);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const especialidad = await Especialidades.findById(id);
        if(!especialidad){
            res.status(404).json({
                mensaje: 'La especialidad no existe'
            })
        }
        res.json(especialidad);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const especialidad = new Especialidades(req.body);
    try {
        await especialidad.save();
        res.json({
            mensaje: 'Se creo una especialidad'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const especialidad = await Especialidades.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo la especialidad'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const especialidad = await Especialidades.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino la especialidad ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}