const Tecnologias  = require('../models/Tecnologia');

//CRUD

exports.lista = async(req, res) => {
    try{
        const Tecnologia = await Tecnologias.find();
        res.json(Tecnologia);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const Tecnologia = await Tecnologias.findById(id);
        if(!Tecnologia){
            res.status(404).json({
                mensaje: 'La tecnologia no existe'
            })
        }
        res.json(Tecnologia);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const Tecnologia = new Tecnologias(req.body);
    try {
        await Tecnologia.save();
        res.json({
            mensaje: 'Se creo una tecnologia'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const Tecnologia = await Tecnologias.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo la tecnologia'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const Tecnologia = await Tecnologias.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino la tecnologia ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}