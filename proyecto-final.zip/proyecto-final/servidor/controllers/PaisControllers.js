const Pais  = require('../models/Pais');

//CRUD

exports.lista = async(req, res) => {
    try{
        const Pai = await Pais.find();
        res.json(Pai);
    } catch (error){
        res.status(400).send(error);
    }
}


exports.seleccionado = async (req, res) =>{
    try {
        const id = req.params.id;
        const Pai = await Pais.findById(id);
        if(!Pai){
            res.status(404).json({
                mensaje: 'El pais no existe'
            })
        }
        res.json(Pai);
    } catch (error) {   
        res.status(400).send(error);
    }
}


exports.agregar  = async(req, res) => {
    const Pai = new Pais(req.body);
    try {
        await Pai.save();
        res.json({
            mensaje: 'Se creo un pais'
        });
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.actualizar  = async(req,res) =>{
    try {
        const id = req.params.id;
        const Pai = await Pais.findOneAndUpdate({
            _id: id
        }, req.body,{
            new: true
        });

        res.json({
            mensaje: 'Se actualizo el pais'
        })
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.eliminar = async(req, res) =>{
    try {
        const id = req.params.id;
        const Pai = await Pais.findOneAndDelete({
            _id: id
        });
        res.json({
            mensaje: `Se elimino el pais ${id} con exito!`
        })
    } catch (error) {
        res.status(400).send(error);
    }
}